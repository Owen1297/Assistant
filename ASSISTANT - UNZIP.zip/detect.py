import keyboard
import os

# init
os.system("cls")
print("WAITING FOR ALT+A")

# mainloop
run = True
while run:
    keyboard.wait("alt+a")
    print("Running Assistant")
    os.system("py C:/Users/laura/OneDrive/Desktop/Assistant/window.pyw")